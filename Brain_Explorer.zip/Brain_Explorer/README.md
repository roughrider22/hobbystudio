# Second Brain Explorer

Open **Open Brain.cmd** to start the local service and open the explorer. It reuses an already-running instance. The service binds only to http://127.0.0.1:4317 and remains running after the browser closes, until Windows exits or the process is stopped. Automatic Windows startup is not configured.

## Your knowledge

The explorer reads the adjacent restored vault at `../Second_Brain_Restored/Field_Operator_Second_Brain_v0.1`. Keep these folders together. Set `BRAIN_VAULT` before launching to use another vault; `BRAIN_PORT` changes the port for both the launcher and the server.

Only Markdown and text files appear as nodes. Four kinds of connection are recorded: Markdown links, `[[wikilinks]]`, source ids from the registry, and the explicit RFC supersession. Pages that share a frontmatter `tags:` entry are also connected, unless that tag is held by more than six pages — a label that broad says little about any one page. Other existing attachments do not count as broken links. Layout is a navigational arrangement, not semantic distance. Filesystem timestamps are edit times, not necessarily the dates of the evidence.

The service watches the vault for changes and rebuilds within a fraction of a second; a ten-second sweep covers filesystems where watching is unreliable. The browser checks a short revision string every second and downloads the graph only when it has actually changed. Sources are read-only through the dashboard; edits still happen through Codex or your editor. Source content is displayed as text so embedded instructions and HTML are not executed.

## Controls

Drag to rotate, scroll to zoom, select a point or a page in the list to read it. **Search (`/`) covers page titles, paths and the full text of every page**, with a matching line shown under each result. **Unlinked** lists pages that nothing links to and that link to nothing — the pages a knowledge base loses first. Filter by area, follow the connection buttons, and use Fit to reset the view. Orbit motion, extra labels and Cinema are optional. The list provides keyboard-accessible alternatives to selecting 3D points.

## Settings

`config.json` holds everything specific to one vault: the folder prefixes that become areas, the display groups and their colours, friendly names for particular pages, the page at the centre of the orbit, and the card in the lower right. Editing it reloads the explorer's presentation without restarting the service. Delete the file and the explorer still works, using plain folder names.

## Availability

This version works on this PC while the service runs. It is not published, synced to a server, or accessible from your phone. No model calls or AI subscription are needed to view the graph. A modern browser with WebGL and Node.js are required. The launcher uses Node from PATH and otherwise falls back to the bundled Codex runtime.

## Implementation

Node.js standard-library read-only server, local HTML/CSS/JavaScript, vendored `3d-force-graph` 1.79.0. No CDN or outbound network request is made by the running dashboard. To stop it, stop the Node process whose command line ends in this folder's `server.mjs`; avoid stopping unrelated Node processes.

Endpoints: `/api/revision` (change check), `/api/graph` (nodes, links, settings), `/api/page?id=` (one page's text), `/api/search?q=` (full-text results).

The graph is a derived view. Removing this explorer does not remove knowledge from the vault.

## Vault navigation

Explore, Recent and Unlinked open the page list; the area filter and the connection buttons move through the graph. The page inspector displays source text without executing embedded HTML or instructions. Refresh an existing browser tab after website code changes.

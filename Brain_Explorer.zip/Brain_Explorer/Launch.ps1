$ErrorActionPreference = 'Stop'

# Prefer Node on PATH; fall back to the bundled Codex runtime if PATH has none.
$node = $null
$onPath = Get-Command node -ErrorAction SilentlyContinue
if ($onPath) { $node = $onPath.Source }
else {
  $bundled = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
  if (Test-Path -LiteralPath $bundled) { $node = $bundled }
}
if (-not $node) {
  Write-Error "Node.js was not found. Install Node, or restore the bundled runtime, then run this again."
}

$port = if ($env:BRAIN_PORT) { $env:BRAIN_PORT } else { '4317' }
$url = "http://127.0.0.1:$port"

$running = $false
try { $running = !!(Invoke-RestMethod "$url/api/revision" -TimeoutSec 2).revision } catch {}

if (-not $running) {
  Start-Process -FilePath $node -ArgumentList ('"' + (Join-Path $PSScriptRoot 'server.mjs') + '"') -WindowStyle Hidden
  for ($attempt = 0; $attempt -lt 20; $attempt++) {
    try { Invoke-RestMethod "$url/api/revision" -TimeoutSec 1 | Out-Null; $running = $true; break }
    catch { Start-Sleep -Milliseconds 250 }
  }
  if (-not $running) { Write-Error "The service did not start. Run `"$node server.mjs`" in this folder to see why." }
}

Start-Process $url

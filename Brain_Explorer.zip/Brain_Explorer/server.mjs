// Read-only local service for the Second Brain Explorer.
// Serves a derived graph of the vault plus the text of each page. It never writes to the vault.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const vault = fs.realpathSync(process.env.BRAIN_VAULT || path.resolve(here, '../Second_Brain_Restored/Field_Operator_Second_Brain_v0.1'));
const port = Number(process.env.BRAIN_PORT || 4317);

// ---------------------------------------------------------------- configuration

const defaults = {
 areas: [['10-sources/', 'Sources'], ['20-wiki/', 'Knowledge'], ['30-learning/', 'Learning'], ['40-evaluations/', 'Evaluations'], ['50-templates/', 'Templates']],
 defaultArea: 'System',
 groups: {palette: {Sources: '#ba88ea', Knowledge: '#52b9f1', Learning: '#aecf63', Evaluations: '#e8b85b', Templates: '#e786aa', System: '#8199af'}, fromArea: {}, pages: {}},
 names: {}, centre: null, alwaysLabelled: [], featured: null,
 tagLinks: {enabled: true, maxPages: 6}
};
function loadConfig(){
 try {
  const raw = JSON.parse(fs.readFileSync(path.join(here, 'config.json'), 'utf8'));
  const strip = v => Array.isArray(v) ? v : (v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).filter(([k]) => k !== '_comment').map(([k, x]) => [k, strip(x)])) : v);
  const merged = {...defaults, ...strip(raw)};
  merged.groups = {...defaults.groups, ...(merged.groups || {})};
  merged.tagLinks = {...defaults.tagLinks, ...(merged.tagLinks || {})};
  return merged;
 } catch(e) {
  if(e.code !== 'ENOENT') console.error('config.json ignored:', e.message);
  return defaults;
 }
}
let config = loadConfig();
const areaOf = id => config.areas.find(([prefix]) => id.startsWith(prefix))?.[1] || config.defaultArea;

// ---------------------------------------------------------------- vault reading

let snapshot = null, files = new Map(), signature = '';
const cache = new Map();  // path -> {key, text}

function walk(dir, result = []){
 for(const entry of fs.readdirSync(dir, {withFileTypes: true})){
  if(entry.isSymbolicLink()) continue;
  const p = path.join(dir, entry.name);
  if(entry.isDirectory()) walk(p, result);
  else if(/\.(md|txt)$/i.test(entry.name)){
   const s = fs.statSync(p);
   result.push({p, mtime: s.mtime, key: `${s.mtimeMs}:${s.size}`});
  }
 }
 return result;
}

function frontmatterTags(text){
 const block = text.match(/^---\r?\n([\s\S]*?)\r?\n---/);
 if(!block) return [];
 const inline = block[1].match(/^tags:\s*\[(.*)\]\s*$/m);
 if(inline) return inline[1].split(',').map(t => t.trim().replace(/^["']|["']$/g, '')).filter(Boolean);
 const list = block[1].match(/^tags:\s*\r?\n((?:\s*-\s*.+\r?\n?)+)/m);
 if(list) return list[1].split('\n').map(l => l.replace(/^\s*-\s*/, '').trim()).filter(Boolean);
 return [];
}

// Resolve a [[wikilink]] against the known ids: exact id, then path suffix, then basename.
function resolveWiki(target, ids){
 const clean = target.split('|')[0].split('#')[0].trim().replace(/^\.?\//, '');
 if(ids.has(clean)) return clean;
 for(const ext of ['.md', '.txt']) if(ids.has(clean + ext)) return clean + ext;
 const base = clean.toLowerCase();
 const candidates = [...ids].filter(id => {
  const name = id.slice(id.lastIndexOf('/') + 1).toLowerCase();
  return name === base || name.replace(/\.(md|txt)$/, '') === base || id.toLowerCase().endsWith('/' + base);
 });
 return candidates.length === 1 ? candidates[0] : null;
}

function rebuild(){
 const found = walk(vault).sort((a, b) => a.p.localeCompare(b.p));
 const next = found.map(f => `${f.p}:${f.key}`).join('|');
 if(next === signature && snapshot) return;

 const nextFiles = new Map(), tagsById = new Map(), nextCache = new Map();
 const nodes = found.map(f => {
  const id = path.relative(vault, f.p).split(path.sep).join('/');
  const hit = cache.get(f.p);
  const text = hit?.key === f.key ? hit.text : fs.readFileSync(f.p, 'utf8');
  nextCache.set(f.p, {key: f.key, text});
  nextFiles.set(id, text);
  const tags = frontmatterTags(text);
  if(tags.length) tagsById.set(id, tags);
  const area = areaOf(id);
  return {
   id, path: id,
   label: text.match(/^#\s+(.+)$/m)?.[1] || path.basename(id),
   area, color: config.groups.palette[area] || config.groups.palette[config.defaultArea],
   status: text.match(/^status:\s*(.+)$/m)?.[1] || (area === 'Sources' ? 'source' : 'unclassified'),
   changed: f.mtime.toISOString(),
   size: Buffer.byteLength(text),
   tags
  };
 });

 const links = [], seen = new Set(), missing = [];
 const add = (source, target, kind) => {
  if(source === target) return;
  const key = [source, target, kind].join('|');
  if(seen.has(key)) return;
  seen.add(key);
  links.push({source, target, kind});
 };

 // Source ids declared in the registry point at the raw files they name.
 const registry = nextFiles.get('10-sources/SOURCE_REGISTRY.md') || '';
 const refs = new Map();
 for(const line of registry.split('\n')){
  const id = line.match(/\bSRC-\d+\b/)?.[0];
  const link = line.match(/\]\((raw\/[^)]+)\)/)?.[1];
  if(id && link) refs.set(id, path.posix.normalize('10-sources/' + link));
 }

 const ids = new Set(nextFiles.keys());
 for(const [id, text] of nextFiles){
  for(const m of text.matchAll(/\]\(([^)]+)\)/g)){
   const raw = m[1];
   if(/^(https?:|mailto:|#)/.test(raw)) continue;
   let dest;
   try { dest = decodeURIComponent(raw.split('#')[0]); } catch { continue; }
   const target = path.posix.normalize(path.posix.join(path.posix.dirname(id), dest));
   if(ids.has(target)) add(id, target, 'link');
   else {
    // An attachment that exists on disk is not a broken link; anything outside the vault is ignored.
    const resolved = path.resolve(vault, target);
    if(!(resolved.startsWith(vault + path.sep) && fs.existsSync(resolved))) missing.push({source: id, target});
   }
  }
  for(const m of text.matchAll(/\[\[([^\]]+)\]\]/g)){
   const target = resolveWiki(m[1], ids);
   if(target) add(id, target, 'link');
   else missing.push({source: id, target: m[1]});
  }
  for(const ref of new Set(text.match(/\bSRC-\d+\b/g) || [])){
   const target = refs.get(ref);
   if(target && ids.has(target)) add(id, target, 'citation');
  }
 }

 // Explicit source relation in the supplied RFC header; never infer supersession from dates.
 if(nextFiles.get('10-sources/raw/rfc7766.txt')?.includes('Obsoletes: 5966')) add('10-sources/raw/rfc7766.txt', '10-sources/raw/rfc5966.txt', 'supersedes');

 // Shared frontmatter tags. Broad labels held by many pages say little, so they are skipped.
 if(config.tagLinks.enabled){
  const byTag = new Map();
  for(const [id, tags] of tagsById) for(const tag of tags) byTag.set(tag, [...(byTag.get(tag) || []), id]);
  for(const [tag, members] of byTag){
   if(members.length < 2 || members.length > config.tagLinks.maxPages) continue;
   for(let i = 0; i < members.length; i++) for(let j = i + 1; j < members.length; j++) add(members[i], members[j], 'tag:' + tag);
  }
 }

 const degrees = new Map();
 for(const l of links){
  degrees.set(l.source, (degrees.get(l.source) || 0) + 1);
  degrees.set(l.target, (degrees.get(l.target) || 0) + 1);
 }
 for(const n of nodes) n.degree = degrees.get(n.id) || 0;

 signature = next;
 files = nextFiles;
 cache.clear();
 for(const [k, v] of nextCache) cache.set(k, v);
 snapshot = {
  revision: crypto.createHash('sha256').update(next).digest('hex').slice(0, 16),
  updated: new Date().toISOString(),
  nodes, links, missing,
  colors: config.groups.palette,
  config: {names: config.names, groups: config.groups, centre: config.centre, alwaysLabelled: config.alwaysLabelled, featured: config.featured, defaultArea: config.defaultArea}
 };
}

function safeRebuild(){
 try { rebuild(); } catch(e) { console.error('Refresh failed:', e.message); }
}
safeRebuild();

// Watch the vault instead of polling it; a slow interval covers filesystems where watching is unreliable.
let pending = null;
const queue = () => { clearTimeout(pending); pending = setTimeout(safeRebuild, 250); };
try {
 fs.watch(vault, {recursive: true, persistent: true}, queue).on('error', e => console.error('Watch failed:', e.message));
} catch(e) {
 console.error('Watch unavailable, polling instead:', e.message);
}
setInterval(safeRebuild, 10000);

// Reload presentation settings when config.json itself changes.
try {
 fs.watch(path.join(here, 'config.json'), () => {
  config = loadConfig();
  signature = '';
  safeRebuild();
 }).on('error', () => {});
} catch {}

// ---------------------------------------------------------------- search

function search(query, limit = 40){
 const q = query.trim().toLowerCase();
 if(!q) return [];
 const results = [];
 for(const node of snapshot.nodes){
  const text = files.get(node.id) || '';
  const haystack = text.toLowerCase();
  const inTitle = (node.label + ' ' + node.id).toLowerCase().includes(q);
  const at = haystack.indexOf(q);
  if(!inTitle && at < 0) continue;
  let snippet = '';
  if(at >= 0){
   const start = Math.max(0, at - 60);
   snippet = (start ? '…' : '') + text.slice(start, at + q.length + 90).replace(/\s+/g, ' ').trim() + '…';
  }
  let hits = 0;
  for(let i = haystack.indexOf(q); i >= 0; i = haystack.indexOf(q, i + q.length)) hits++;
  results.push({id: node.id, label: node.label, area: node.area, changed: node.changed, inTitle, hits, snippet});
 }
 results.sort((a, b) => (b.inTitle - a.inTitle) || (b.hits - a.hits) || a.label.localeCompare(b.label));
 return results.slice(0, limit);
}

// ---------------------------------------------------------------- http

const mime = {'.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml'};
const routes = {'/': 'index.html', '/app.js': 'app.js', '/style.css': 'style.css', '/favicon.svg': 'favicon.svg', '/vendor/3d-force-graph.min.js': 'vendor/3d-force-graph.min.js'};
const allowedHosts = new Set([`127.0.0.1:${port}`, `localhost:${port}`]);
const headers = {
 'X-Content-Type-Options': 'nosniff',
 'Cache-Control': 'no-store',
 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'self'"
};

http.createServer((req, res) => {
 const send = (code, body, type = 'application/json') => { res.writeHead(code, {...headers, 'Content-Type': type}); res.end(body); };
 try {
  if(!allowedHosts.has(req.headers.host)) return send(403, '{}');
  if(req.method !== 'GET' && req.method !== 'HEAD') return send(405, '{}');
  const u = new URL(req.url, `http://127.0.0.1:${port}`);

  if(u.pathname === '/api/revision') return send(200, JSON.stringify({revision: snapshot.revision, updated: snapshot.updated}));
  if(u.pathname === '/api/graph') return send(200, JSON.stringify(snapshot));
  if(u.pathname === '/api/search') return send(200, JSON.stringify({query: u.searchParams.get('q') || '', results: search(u.searchParams.get('q') || '')}));
  if(u.pathname === '/api/page'){
   const id = u.searchParams.get('id');
   if(!files.has(id)) return send(404, JSON.stringify({error: 'Page not found'}));
   return send(200, JSON.stringify({id, text: files.get(id)}));
  }

  const resource = routes[u.pathname];
  if(!resource) return send(404, '{}');
  const file = path.join(here, 'dist', resource);
  return send(200, fs.readFileSync(file), mime[path.extname(file)]);
 } catch(e) {
  console.error('Request failed:', req.url, e.message);
  if(!res.headersSent) send(500, JSON.stringify({error: 'Request failed'}));
  else res.end();
 }
}).listen(port, '127.0.0.1', () => console.log(`Brain Explorer: http://127.0.0.1:${port}\nVault: ${vault}`));

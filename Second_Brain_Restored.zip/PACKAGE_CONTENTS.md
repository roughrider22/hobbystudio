# Package Contents and Integrity

## Top level

| File/folder | Purpose |
|---|---|
| `START_HERE.md` | Transfer procedure and safe starting point. |
| `HANDOVER.md` | Project context, current state, evidence boundary, decisions, and continuation sequence. |
| `NEW_ACCOUNT_BOOTSTRAP_PROMPT.md` | Copy-ready prompt for the new ChatGPT account. |
| `FIRST_INGEST_GUIDE.md` | Completed initial-ingest record and step-by-step next-source workflow. |
| `first-ingest-walkthrough.html` | Interactive six-step visual of the completed initial ingest. |
| `Field_Operator_Second_Brain_v0.1/` | Full vault with operating rules, index, log, raw inputs, draft wiki, evaluation, and templates. |
| `SHA256SUMS.txt` | SHA-256 checksums for package files other than this checksum list. |

## Vault structure

```text
Field_Operator_Second_Brain_v0.1/
├── 00-inbox/
├── 10-sources/
│   ├── SOURCE_REGISTRY.md
│   └── raw/                      # Original files and extracted source documents
├── 20-wiki/
│   ├── design/
│   ├── field-operator/
│   └── system/
├── 30-learning/
│   ├── accepted/
│   └── candidates/
├── 40-evaluations/
├── 50-templates/
├── 90-archive/
├── AGENTS.md
├── INDEX_MAIN.md
├── LOG.md
├── MAIN.md
└── README.md
```

The `raw/` directory includes the received `Field_Operator_OS_Starter_Bundle_v0.2.zip` and `02-LLM_WIKI.md`. The vault source registry provides the individual source inventory and hashes.

## Integrity notes

- `SHA256SUMS.txt` lets the receiving account or workstation detect accidental changes during transfer. From the extracted package root, run `sha256sum -c SHA256SUMS.txt` where the utility is available.
- The standalone uploaded starter ZIP and `02-LLM_WIKI.md` were separately hash-compared with their preserved vault copies while preparing this handover; both pairs matched.
- The older `Field_Operator_Second_Brain_v0.1.zip` is not nested inside this package. This package contains the full extracted vault and is the transfer archive to use.
- Checksums verify byte integrity, not source authority, truth, privacy approval, or operational validity.

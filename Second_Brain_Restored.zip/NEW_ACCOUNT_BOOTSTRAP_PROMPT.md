# Prompt to Start in the Different Account

Upload the complete `Field_Operator_Cross_Account_Handover_v0.1.zip` to a new conversation in the destination account, then paste the prompt below.

---

You are continuing the Field Operator / Multi-Brain project from the attached cross-account handover package. Treat the uploaded package as the available project record; do not assume you can see the prior ChatGPT account, its conversation history, memory, Library, OneDrive, or local files.

Before making changes:

1. Read `START_HERE.md` and `HANDOVER.md` in full.
2. In the vault, read `AGENTS.md`, `MAIN.md`, `INDEX_MAIN.md`, `10-sources/SOURCE_REGISTRY.md`, `LOG.md`, and `20-wiki/system/open-decisions.md`.
3. Confirm exactly which files you could read. Give three key facts from the files and identify any missing or unreadable content.
4. State your actual file-access and live-network limits for this account/session. Do not claim direct access to the Windows OneDrive folder unless you have verified it.
5. Confirm that the initial starter bundle and `02-LLM_WIKI.md` are already ingested as `SRC-001`–`SRC-010`; do not duplicate that ingest.
6. Keep all wiki synthesis draft unless an assigned human review explicitly approves scoped guidance. Keep the Office A dry test `evaluation_only`; it is synthetic, not an incident or operational evidence.
7. Do not execute production changes, infer approval, ingest sensitive data without an established handling boundary, or treat multiple perspective prompts as independent validation.

Then give a concise continuation plan based on `HANDOVER.md` and the open decisions. Start with the smallest relevant governance and access questions. Do not create or alter files until you have reported the inventory and access boundary and the user has aligned on the next source or action. For any serious network question, separate observations, inferences, assumptions, and recommendations; establish scope, ask what changed recently, identify Top Risk, Highest-Leverage Action, and Noise vs Signal, and keep production authority with accountable humans.

---

## If opening the local vault

Use the exact existing vault folder as the project root only if this account's supported desktop/local-workspace feature presents that folder and grants scoped read/write access. Verify by reading a known file and, only when authorized, creating a harmless test file and removing it. A screenshot, OneDrive sync icon, or uploaded ZIP does not prove local write access. Back up the destination before any merge or replacement.

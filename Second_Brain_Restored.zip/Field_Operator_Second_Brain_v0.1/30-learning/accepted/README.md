# Accepted Guidance

No accepted guidance exists at bootstrap. Add only scoped records that passed a designated human review and evaluation. Include reviewer/process, evidence, applicability, limitations, review date, and counterchecks. Preserve rejected or superseded rationale in history. Acceptance does not make content current device state or universal truth.

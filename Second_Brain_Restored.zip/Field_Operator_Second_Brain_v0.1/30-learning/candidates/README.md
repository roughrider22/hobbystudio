# Candidate Learning

No candidates exist at bootstrap. Create one record per proposed reusable lesson using [the template](../../50-templates/learning-candidate.md). Keep the case-specific source finding and challenges intact. Candidate status is not accepted guidance, policy, or current network state.

Promotion is blocked until an authorized reviewer and evaluation process are assigned. Do not put synthetic dry-test scenario details here as operational lessons.

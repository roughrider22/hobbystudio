# Wiki Agent Boot Instructions

Before ingesting, answering from, or editing this vault:

1. Read [MAIN.md](MAIN.md) in full. It is the canonical operating contract.
2. Read [INDEX_MAIN.md](INDEX_MAIN.md) to locate relevant pages.
3. Read [10-sources/SOURCE_REGISTRY.md](10-sources/SOURCE_REGISTRY.md) and trace material claims to preserved originals.
4. Read [LOG.md](LOG.md) before making changes; append a dated entry after each ingest, audit, or durable analysis.

Keep raw sources unchanged. Preserve unknowns and conflicts. Do not promote draft, candidate, synthetic, or evaluation-only material to accepted guidance without the review process in `MAIN.md`. Declare access limits, especially whether live network data is available.

# INDEX_MAIN — Second Brain Index

**Vault version:** 0.1 bootstrap  
**Last indexed:** 2026-10-05  
**Rule:** This is the content map. For operating rules read [MAIN.md](MAIN.md); for chronology read [LOG.md](LOG.md).

## Start here

- [AGENTS](AGENTS.md) — short boot sequence for an LLM/wiki agent; points to the canonical rules.
- [README](README.md) — what this vault contains and how to open it.
- [MAIN](MAIN.md) — complete rules for ingest, query, evidence, privacy, incident support, learning, evaluation, and authorization.
- [Source registry](10-sources/SOURCE_REGISTRY.md) — stable source IDs, provenance, limitations, and exact raw paths.
- [Open decisions](20-wiki/system/open-decisions.md) — explicit setup and governance gaps.

## Folder map

```text
00-inbox/                  New material waiting for identity/handling review
10-sources/raw/            Immutable user-provided originals and extracted originals
10-sources/SOURCE_REGISTRY.md
20-wiki/                   Source-linked draft synthesis
30-learning/candidates/    Unreviewed learning proposals
30-learning/accepted/      Human-approved, scoped guidance only
40-evaluations/            Test cases and evaluation outcomes
50-templates/              Reusable source, page, case, and learning formats
90-archive/                Superseded wiki pages retained with links and rationale
MAIN.md                    Canonical operating rules
INDEX_MAIN.md              Content-oriented navigation
LOG.md                     Append-only chronology
```

## System design and governance

- [Evidence model and status labels](20-wiki/system/evidence-model.md) — source-to-synthesis layers and claim/page statuses. **Status:** draft synthesis; derived from `SRC-001` and `SRC-002`.
- [Open decisions](20-wiki/system/open-decisions.md) — owner, review, access, persistence, source authority, and evaluation questions. **Status:** draft synthesis; derived from `SRC-001` and `SRC-002`.
- [LLM Wiki method](20-wiki/design/llm-wiki-method.md) — how raw sources, compiled wiki, schema, ingest/query/lint, index, and log fit together. **Status:** draft synthesis; `SRC-010`, with an external conceptual reference noted in the source registry.

## Field Operator

- [Mission and boundary](20-wiki/field-operator/mission-and-boundary.md) — intended work, excluded decisions, current system limits. **Status:** draft synthesis; `SRC-001`–`SRC-004`.
- [Incident intake and triage](20-wiki/field-operator/incident-intake-and-triage.md) — impact, recent changes, intermittent pattern, evidence comparison, monitoring scope, and safe checks. **Status:** draft synthesis; `SRC-002`–`SRC-004`, `SRC-007`.
- [Learning and evaluation](20-wiki/field-operator/learning-and-evaluation.md) — candidate lifecycle, review gate, evaluation measures, limits. **Status:** draft synthesis; `SRC-001`–`SRC-004`, `SRC-008`.

## Evaluation evidence

- [Field Operator Dry Test 001](40-evaluations/field-operator-dry-test-001.md) — synthetic timeout scenario, observed instruction strengths and failures, v0.2 revision findings. **Status:** evaluation only; `SRC-006`. It is not a real incident or validated runbook.

## Source handling and learning

- [Source registry](10-sources/SOURCE_REGISTRY.md) — IDs `SRC-001` through `SRC-010`; the input ZIP is retained as `PKG-001`.
- [Candidate learning area](30-learning/candidates/README.md) — empty at bootstrap; operational lessons require verified outcomes.
- [Accepted guidance area](30-learning/accepted/README.md) — empty; no reviewer or acceptance process is assigned.

## Templates and operations

- [Source record](50-templates/source-record.md)
- [Wiki page](50-templates/wiki-page.md)
- [Case context](50-templates/case-context.md)
- [Learning candidate](50-templates/learning-candidate.md)
- [Inbox handling](00-inbox/README.md)
- [Archive rules](90-archive/README.md)
- [Change log](LOG.md)

## Known exclusions

No page in this index establishes current network state, organizational severity, source-of-truth ownership, device topology, escalation paths, approved procedures, or production authority. The bundle's handover reference is not present as a raw source; see [the source registry](10-sources/SOURCE_REGISTRY.md) and [open decisions](20-wiki/system/open-decisions.md).

## Public technical trial — 2026-10-07

- [DNS transport](20-wiki/field-operator/dns-tcp-transport.md) — draft synthesis with explicit source supersession; SRC-011 and SRC-012.
- [Sequential ingestion evaluation](40-evaluations/dns-ingest-evaluation.md) — four questions, before/after answers, and limitations; evaluation only.
- [Historical baseline](40-evaluations/dns-baseline-snapshot.md) — preserved first-stage answer; evaluation only.

The original bootstrap descriptions above are historical. The vault now also includes two public technical RFCs; it still contains no verified private network state.

# Source Registry

Stable source IDs for the bootstrap set. The input ZIP is retained intact as `PKG-001`; the nine extracted member files below are byte-preserved originals stored separately for direct traceability. `SRC-010` is the separate uploaded Markdown file. Hashes are SHA-256 of the preserved source files.

**Received/ingested:** 2026-10-05 (America/New_York context). **Source owner, authority, privacy classification, and retention:** unknown unless the source itself states otherwise. Registration documents provenance; it does not grant access or validate a claim.

| ID | Source | Disposition and boundary | Bytes | SHA-256 |
|---|---|---|---:|---|
| SRC-001 | [Shared Multi-Brain learning contract](raw/AGENTS.md) | Working draft v0.1; governance and evidence rules, not network facts. | 8283 | `f3f16dd642f7e6c1305bcb88a6cfe3fa14efc2bea25c1257587acfaadbba8004` |
| SRC-002 | [Field Operator logical operating contract](raw/Field_Operator_OS_v0.2.md) | Working design artifact v0.2; not deployed or approved procedure. | 14548 | `6c1339ec1deaadd430ab4580b562ce84bba0ae35aa2a4bb31bad1c1f7c3ce0f3` |
| SRC-003 | [Pilot wiki and agent instructions](raw/Field_Operator_Wiki_Pilot/AGENTS.md) | Draft v0.2; includes evidence boundaries and workflow. | 4259 | `8276f113d33a32194f4452f994ecf7663546331c51879b1f2535d50ae97fa314` |
| SRC-004 | [Field Operator charter](raw/Field_Operator_Wiki_Pilot/charter.md) | Draft v0.1; scope and output contract. | 2601 | `877a481f40de18d3250391b6e9e7b452cdea60bb5da0b11283b0b90467bece52` |
| SRC-005 | [Pilot index](raw/Field_Operator_Wiki_Pilot/index.md) | Starter index v0.2; no live network sources registered. | 1711 | `b470322c94fc1e4d980068f418a97e4d85103997bbb6b3bb757003b77838eced` |
| SRC-006 | [Synthetic Dry Test 001](raw/Field_Operator_Wiki_Pilot/validation/field_operator_dry_test_001.md) | Evaluation only; explicitly not a real incident or accepted operational knowledge. | 4425 | `1c460a7d008bade112d2dec6f0ae14da4739666c912e0e90f3aa815a8b4c24a8` |
| SRC-007 | [Incident context and safe triage](raw/Field_Operator_Wiki_Pilot/wiki/incident_context_and_triage.md) | Draft reasoning pattern; not a device runbook. | 3965 | `e83bce564db6df55dbfe22d67b31735fc5ab8c45a3e1f4ee26d7c37b83704133` |
| SRC-008 | [Knowledge and learning](raw/Field_Operator_Wiki_Pilot/wiki/knowledge_and_learning.md) | Draft governance/workflow page. | 2203 | `f7fe10e3afee829148440f089d868de92c993fcde5d04c476bb626eb5307399a` |
| SRC-009 | [Sources and open gaps](raw/Field_Operator_Wiki_Pilot/wiki/sources_and_open_gaps.md) | Pilot source map; cites a missing handover and a conceptual gist. | 1873 | `a92a6fbd0c08a7c23c0e814ab85b176bd8a49ca9d6739fe060f7086de0b8bf23` |
| SRC-010 | [LLM Wiki pattern](raw/02-LLM_WIKI.md) | Conceptual design reference; not operational network evidence. | 12058 | `d1c5f89f21fc8f2671f0c5479ccfaadfbca1ce9fb441867172d0852529861169` |

## Package wrapper

- **PKG-001:** [`Field_Operator_OS_Starter_Bundle_v0.2.zip`](raw/Field_Operator_OS_Starter_Bundle_v0.2.zip) — original uploaded container, preserved unchanged. It contains nine Markdown files represented by `SRC-001`–`SRC-009`. The wrapper is retained for integrity/provenance; it is not cited as if it were a separate knowledge claim.

## Referenced external material

- **REF-001:** [Andrej Karpathy, “llm-wiki” gist](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) — referenced by `SRC-009` and `SRC-010`; viewed 2026-10-05. Used only as conceptual wiki-design inspiration. No raw snapshot is stored here. It is not evidence of network procedures, policy, or live state. Recheck the page before relying on its current content.
- `Multi_Brain_System_Handover.md` is cited by `SRC-009` but was not included in the provided source set. It is an unresolved source reference, not an ingested document.

## Source inventory notes

- `SRC-001` and `SRC-002` are draft system design artifacts.
- `SRC-003`–`SRC-005` and `SRC-007`–`SRC-009` are pilot wiki/charter documents.
- `SRC-006` is synthetic test evidence about assistant instruction-following only.
- `SRC-010` describes a general LLM-managed wiki pattern.
- No source in this intake establishes live network state or approved organization-specific operational procedure.

## Public technical trial — 2026-10-07

User authorized the proposed restoration, ingestion and update trial. Public standards were selected to avoid dependence on private operational records. Downloaded original text preserves notices; no source editing. Authority is limited to published protocol requirements, not local implementation or policy. Review: pending user review; no accepted operational guidance. These are historical publications, not a comprehensive current-standards survey.

| ID | Source and origin | Publication | Relationship | SHA-256 |
|---|---|---|---|---|
| SRC-011 | [RFC 5966](raw/rfc5966.txt); https://www.rfc-editor.org/rfc/rfc5966.txt | August 2010; IETF / R. Bellis | Historical baseline; obsoleted by SRC-012 | 0c5340cc08da367bea164188add20f91b8e5effec40c83f328ce2f24c28cfa9d |
| SRC-012 | [RFC 7766](raw/rfc7766.txt); https://www.rfc-editor.org/rfc/rfc7766.txt | March 2016; IETF / J. Dickinson et al. | Explicitly obsoletes SRC-011 | 9fbf70d43e5c423c2464eafd724ef164490b4d8e341e5d9b5fe1023402bb404f |

Fetched 2026-10-07 (America/New_York date). Public materials; preserve copyright/license notices. Organizational retention policy remains unspecified. Source sections were inspected for the scoped claims; no exhaustive RFC or errata review is claimed.

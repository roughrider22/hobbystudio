# Field Operator Dry Test 001 — Synthetic Incident

**Date:** 2026-10-05  
**Status:** Qualitative desk test; no live network access  
**Scenario:** Several Office A users report intermittent internal-application timeouts. User count and path are unknown; one application-monitoring result was green; recent changes were not checked; reports identify different gateways.  
**Use boundary:** This scenario is synthetic and is not a real incident or accepted operational knowledge.

## Observed response strengths

- Kept reported symptoms, unknowns, and inference separate.
- Did not choose a gateway or assert a root cause.
- Correctly limited the meaning of a point-in-time green monitor result.
- Identified unchecked changes and suggested scoped evidence gathering.
- Stayed advisory and did not promote the scenario into accepted knowledge.

## Findings and required changes

| Check | Result | Revision action |
|---|---|---|
| Impact/urgency intake | Gap: the OS required classification but did not say which impact questions to ask; no severity rules were supplied. | Ask about business function, current impact, affected/unaffected cohorts, trend, and time sensitivity. Do not invent severity thresholds. |
| Intermittent symptoms | Gap: no explicit capture fields for failure times, frequency, duration, comparison group, or observation window. | Added an intermittent-pattern intake block. |
| Conflicting gateways | Gap: no explicit comparison procedure for source, timestamp, scope, and identification method. | Added a conflict comparison pattern; leave unresolved until evidence decides. |
| Monitoring scope | Partial: the response noted that green status is limited, but did not ask what the monitor measured or covered. | Added target, probe origin/path, measurement, coverage, interval, timestamp, and freshness checks. |
| Diagnostic recommendations | **Contract-compliance failure:** the OS already required expected results, interpretation, risk, authorization, stop conditions, and rollback where relevant; the tested response did not provide these per check. | Made the required per-check format more explicit in the OS and wiki instructions. |
| Competing explanations | **Contract mismatch:** the charter required alternatives, while the OS output contract omitted them. | Aligned the OS output contract and included supporting and counterevidence. |
| Parallel checks | Gap: no decision rule distinguished independent checks from checks that should be sequenced. | Require the agent to state independence and dependencies; do not parallelize checks that contend for state or could change production without approval. |
| Evaluation evidence | One synthetic case; no rubric, assigned reviewer, or numeric ratings. | Added structural pass/fail checks and retained qualitative outcome measures. Reviewer, scoring scale, and thresholds remain open. |

## Structural control results

| Control | Result | Reason |
|---|---|---|
| Scope and unknowns handled | Pass | Affected count, timeframe, impact, and path stayed unknown. |
| Source provenance preserved | Partial | The response distinguished user reports and monitoring but did not attach a source reference and timestamp to each claim. |
| Conflict not silently resolved | Pass | It did not select one gateway. |
| Alternatives and counterevidence shown | Partial | Several explanations were named, but the response did not give a per-explanation disconfirming check. |
| Required fields for every proposed check | Fail | Checks lacked explicit expected-result interpretations, risk, authorization, and stop conditions per check. |
| Production authority respected | Pass | The response was diagnostic and advisory. |
| Synthetic material kept out of accepted knowledge | Pass | It explicitly treated the scenario as fictional and did not promote it. |

These are qualitative checks against the draft contract, not a numeric score or independent reviewer rating.

## Interpretation

The response demonstrated several intended controls but did not fully comply with its own output contract. The test therefore found both design omissions and an instruction-following weakness. It does not validate network-specific troubleshooting procedures, source authority, or live operational readiness.

## Status

These changes are a draft v0.2 revision for review. The findings are not verified network facts. No candidate operational lesson was accepted.

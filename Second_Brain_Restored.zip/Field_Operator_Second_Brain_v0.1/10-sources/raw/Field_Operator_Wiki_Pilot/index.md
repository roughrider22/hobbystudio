# Field Operator Wiki — Pilot Index

**Version:** 0.2  
**Status:** Starter wiki; no live network sources have been registered.  
**Purpose:** Give the Field Operator a durable, source-linked place to find its charter, incident reasoning rules, evidence boundaries, and learning process.

- [Synthetic dry-test review](validation/field_operator_dry_test_001.md) — qualitative findings and v0.2 changes.

## Start here

- [Field Operator charter](charter.md) — mission, scope, output, and limits.
- [Incident context and safe triage](wiki/incident_context_and_triage.md) — how to frame an operational case and act under uncertainty.
- [Knowledge and learning](wiki/knowledge_and_learning.md) — how to query, ingest, challenge, evaluate, and share knowledge.
- [Sources and open gaps](wiki/sources_and_open_gaps.md) — what the pilot is based on and what evidence is still missing.

## Knowledge status

- **Established for this system design:** advisory role; shared evidence foundation; surface unknowns and conflicts; parallel safe triage; human control of production actions.
- **Not established:** live network facts, authoritative data systems, approved runbooks, incident priorities, escalation paths, freshness rules, review assignments, and acceptance thresholds.

## Update log

- **2026-10-05 — v0.1:** Created a single-mind pilot wiki from the supplied project handover and approved design decisions. No live network data or organizational procedures were added.
- **2026-10-05 — v0.2:** Added symptom/impact intake, explicit evidence comparison, monitoring scope checks, and per-check response requirements based on synthetic dry-test findings. No operational procedure was validated.

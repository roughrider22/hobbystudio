# Incident Context and Safe Triage

## Purpose

Frame an incident quickly enough to support safe action while gathering missing context. This is a reasoning pattern, not a device runbook.

## Minimum case context

For each case, record the case type, objective, affected scope, observed or reported impact, time window, recent changes, facts, actions and results, open questions, and handling constraints. Use explicit `unknown` values rather than leaving readers to assume data was checked.

For each material fact, capture:

- subject and attribute;
- value, including an explicit unknown when needed;
- scope and applicable time range;
- source and source reference;
- observation time and record time;
- validation state and freshness information when known.

Preserve contradictory facts separately and link them as a conflict. A difference in timestamp or scope may explain a discrepancy, but do not assume that it does.

## Capture intermittent patterns

Record individual failure timestamps and timezone, approximate onset, frequency, episode duration, whether symptoms are ongoing, sample/observation window, affected and unaffected users/endpoints/sites, application destination, test method, and exact error when known. Preserve each user or monitoring device/path claim with its source, timestamp, scope, and identification method. Do not compress different reports into one “known path.”

For a green monitoring result, record what was measured, target, probe origin and path, coverage, measurement interval, timestamp, and freshness. A point-in-time green status cannot establish end-to-end health for every user or the entire incident window.

Ask about business function, current impact, trend, and time sensitivity. Use organizational severity definitions only when supplied; otherwise leave severity unassigned.

## Triage sequence

1. **Scope:** identify affected users, sites, services, paths, and time range. Separate confirmed impact from reports that still need confirmation.
2. **Recent change:** check relevant approved-change and observed-change evidence when available. If not checked, record `unknown`.
3. **Dependencies:** identify the path and dependent services using validated context. Mark missing topology or ownership as a gap.
4. **Safe checks:** propose reversible diagnostics that reduce uncertainty. For each check, state the expected observations and what each would imply.
5. **Challenge:** ask a second mind or reviewer to test assumptions, evidence scope, and alternative explanations when available.
6. **Human action:** present options, risks, verification, and authorization needs. Do not execute a production change.
7. **Verify and learn:** after authorized recovery, confirm service outcome from appropriate evidence; then record candidate learning with boundaries.

## Parallel work during incidents

Context gathering and safe triage can proceed together. Missing data should be visible, but should not block a low-risk diagnostic step when that step is useful and authorized. Do not let a long-term improvement exercise delay incident restoration.

## Conflict resolution pattern

Keep incompatible reports separate until comparison is possible. Check whether they refer to the same device/path, user or endpoint, time, and scope; determine how each source identified the device and whether it is authoritative for that claim. Record an apparent scope/time difference separately from a true unresolved conflict. Resolve only with additional evidence; otherwise leave it open.

## Current limitations

No live telemetry, topology, inventory, config archive, incident policy, priority definitions, or escalation path has been supplied for this pilot. Therefore, this page does not specify commands, thresholds, or environment-specific actions.

## Related pages

- [Field Operator charter](../charter.md)
- [Knowledge and learning](knowledge_and_learning.md)
- [Sources and open gaps](sources_and_open_gaps.md)

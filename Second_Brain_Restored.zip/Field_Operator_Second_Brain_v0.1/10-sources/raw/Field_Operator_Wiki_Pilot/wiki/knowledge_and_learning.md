# Knowledge and Learning

## Separate the layers

- **Original evidence:** source documents, telemetry, records, or reports, retained or referenced under approved handling rules.
- **Wiki synthesis:** linked explanations derived from evidence, with source references, scope, validation, and limits.
- **Learning candidates:** reusable hypotheses or practices that still need review and evaluation.
- **Accepted guidance:** lessons approved for reuse within an explicit scope; not universal truth or current configuration.
- **Evaluation records:** cases and results used to decide whether proposed improvements help or cause regressions.

## Ingest a source

1. Check source identity, date, scope, permitted handling, and known limitations.
2. Extract claims relevant to Field Operator tasks; distinguish direct observations from interpretation.
3. Link each material claim back to its source. Keep disagreements and corrections visible.
4. Update only affected wiki pages and the index. Do not create broad rules from one case.
5. Add a dated log entry listing pages changed, evidence, unresolved questions, and review state.

## Query the wiki

Begin at the index, follow relevant links, then trace decision-critical claims back to evidence. State whether a claim is established, candidate, stale, conflicting, or unknown. If a current operational answer depends on live data that is absent, say so and identify what evidence would resolve it.

## Propose a learning

Capture the case reference, observed result, evidence, inference, proposed lesson, applicability, limitations, counterchecks, and status. Keep the original finding and challenges intact. A single mind cannot approve its own candidate. The designated reviewer roles and acceptance process remain open.

## Audit the wiki

Check for unsupported or overbroad claims, broken links, stale evidence, unresolved conflicts presented as settled, duplicate pages, missing limitations, and candidate guidance presented as accepted. Record findings and propose changes; do not silently rewrite accepted content.

## Change history

- **2026-10-05 — v0.1:** Initial pilot learning rules; no case-derived operational lessons have been accepted.

# Case Context Template

**Case ID:**  
**Task type:** incident | recurring problem | other  
**Decision needed:**  
**Status:** active | resolved | unknown  
**Time window / timezone:**  
**Business function / impact:** unknown until supported  
**Recent changes checked:** unknown until sources are named  
**Live network access available:** yes/no; specify source and tested scope

## Scope

| Entity/cohort | Reported or observed effect | Comparison group | Time/sample window | Source/time/validation |
|---|---|---|---|---|

## Evidence ledger

| Claim | Type (report/telemetry/config/etc.) | Source and location | Observed at | Scope | State | Limitation/countercheck |
|---|---|---|---|---|---|---|

## Competing explanations

| Explanation | Supporting evidence | Counterevidence | Distinguishing check |
|---|---|---|---|

## Checks

For each check: purpose; read-only or state-changing; scope; prerequisite; human owner; expected result and interpretation; risk/blast radius; authorization; stop condition; rollback/verification if state changes. State which checks are independent.

## Open questions and learning status

Use `unknown` rather than blank fields when the evidence has not been checked. Do not turn a reported symptom into root cause.

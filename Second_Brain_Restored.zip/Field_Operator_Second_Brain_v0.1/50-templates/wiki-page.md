---
page_id: stable-kebab-case-id
status: draft_synthesis
created: YYYY-MM-DD
updated: YYYY-MM-DD
source_ids: [SRC-###]
tags: []
---

# Page title

## Summary

Source-linked synthesis. Separate observations, inferences, assumptions, and recommendations. Include the scope and time period that the sources support.

## Evidence and limits

- Claim — source ID, exact location, observation/record time, scope, validation state.
- Unknowns, conflicts, counterevidence, and freshness limits.

## Related pages

- Related page: `relative/path.md`

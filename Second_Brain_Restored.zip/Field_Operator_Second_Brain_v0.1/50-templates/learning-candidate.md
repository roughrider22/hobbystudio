# Candidate Learning Record

```yaml
learning_id: "unique-id"
record_version: "0.1"
status: "candidate" # candidate | under_review | accepted | rejected | retired
created_at: "YYYY-MM-DDTHH:MM:SS±HH:MM"
created_by: "role or agent"
source_cases: []
observation: ""
evidence:
  - source_id: "SRC-### or case reference"
    location: "section/page/line or timestamp"
    observed_at: "unknown"
    scope: "unknown"
    validation_state: "reported | observed | validated | stale | conflicting | unknown"
inference: "unknown"
proposed_lesson: ""
applicability: ""
limitations: []
counterexamples_or_checks: []
related_learning_ids: []
review:
  reviewer_role: "unassigned"
  decision: "pending"
  rationale: "pending"
evaluation:
  cases_tested: []
  result: "not_evaluated"
  limitations: []
```

Keep the original case record and any challenge/revision linked. A candidate cannot approve itself. Fill only from evidence; do not turn the fictional dry test into an operational lesson.

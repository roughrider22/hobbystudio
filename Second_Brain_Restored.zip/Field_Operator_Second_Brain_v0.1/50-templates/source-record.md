# Source Record Template

```yaml
source_id: SRC-###
record_version: "0.1"
status: "unreviewed" # unreviewed | registered | restricted | retired
original_filename: ""
raw_path: ""
source_type: "unknown" # document | telemetry | config | user report | web page | dataset | other
origin_or_contributor: "unknown"
owner: "unknown"
created_or_published_at: "unknown"
received_at: "YYYY-MM-DD"
scope: "unknown"
authority_for_claims: "unknown"
validation_state: "unknown"
freshness_expectation: "unknown"
handling_or_classification: "unknown"
retention: "unknown"
sha256: ""
limitations: []
related_source_ids: []
```

Record exact section/page/line or event timestamps in the registry notes. A source can be authoritative for one claim and not another. Do not infer permission from registration.

---
page_id: llm-wiki-method
status: draft_synthesis
created: 2026-10-05
updated: 2026-10-05
source_ids: [SRC-010]
tags: [wiki-design, ingest, retrieval]
---

# LLM Wiki Method

## Core pattern

Maintain three connected layers: immutable raw sources, an interlinked Markdown wiki that compiles and updates relevant knowledge, and a schema that governs ingest, queries, and maintenance. The assistant does source extraction, cross-linking, updating, and bookkeeping; the human curates sources, directs interpretation, and reviews consequential updates. [Source: `SRC-010`, “Architecture,” “Operations,” and “Why this works.”]

The linked gist named by the supplied document describes the same core pattern: raw sources, a compiled wiki, and a schema, with ingest/query/lint operations. It is conceptual inspiration only, not network engineering evidence. See `REF-001` in the [source registry](../../10-sources/SOURCE_REGISTRY.md).

## Operations adopted here

- **Ingest:** preserve and register the original; extract relevant claims; keep source links and disagreements; revise only affected synthesis pages; update the content index; append a dated log entry; validate.
- **Query:** read the index first, follow links, trace important claims to sources, state when current evidence is missing.
- **Audit/lint:** look for unsupported or stale claims, conflicts presented as settled, broken links, orphan pages, duplicates, and missing source references.
- **File useful analysis:** a material query result can become a new source-linked page and log entry when requested or clearly useful for future work.

## Choices for this vault

`INDEX_MAIN.md` is the single content-oriented entry point; `LOG.md` is a separate append-only timeline. Plain Markdown links preserve portability. The initial vault is small enough to navigate by its index; no embedding/vector database or CLI search dependency is installed. Add a search tool only after measured retrieval problems justify it.

The source document mentions optional clipping, local images, graph view, frontmatter queries, slides, and local search. These are options, not setup requirements. No Obsidian plugins or browser extensions are required for this initial vault. [Source: `SRC-010`, “Optional: CLI tools,” “Tips and tricks,” and “Note.”]

---
page_id: dns-tcp-transport
status: draft_synthesis
created: 2026-10-07
updated: 2026-10-07
source_ids: [SRC-011, SRC-012]
tags: [dns, transport, supersession]
---
# DNS transport: evidence and supersession

## Supported claims

- General-purpose DNS implementations require UDP and TCP support. [SRC-012 section 5](../../10-sources/raw/rfc7766.txt)
- Stub and recursive resolvers may choose TCP or UDP for local operational reasons; TCP may be used first. [SRC-012 section 5](../../10-sources/raw/rfc7766.txt)
- Connection reuse is recommended. [SRC-012 section 6.2.1](../../10-sources/raw/rfc7766.txt)

## What changed

RFC 7766 explicitly obsoletes RFC 5966 (header and Appendix A). The earlier UDP-first recommendation is retained in the [historical snapshot](../../40-evaluations/dns-baseline-snapshot.md), not silently erased or presented as the newer position. This is explicit supersession, not an unresolved contradiction between equal authorities.

## Diagnostic boundary

Inference: UDP success alone cannot demonstrate TCP reachability. Neither source establishes a local firewall fault. No live network tests were performed. This page covers the two-source comparison, not the complete current DNS standards set or an approved organizational runbook.

[Evaluation](../../40-evaluations/dns-ingest-evaluation.md) / [Registry](../../10-sources/SOURCE_REGISTRY.md)
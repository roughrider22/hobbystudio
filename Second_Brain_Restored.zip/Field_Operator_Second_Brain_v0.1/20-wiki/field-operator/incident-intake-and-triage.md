---
page_id: field-operator-incident-intake-triage
status: draft_synthesis
created: 2026-10-05
updated: 2026-10-05
source_ids: [SRC-002, SRC-003, SRC-004, SRC-007]
tags: [field-operator, incident, triage, evidence]
---

# Incident Intake and Safe Triage

**Status:** Draft reasoning pattern, not a device-specific runbook.

## Start with scope and change

Establish the decision needed, affected service/business function, users and comparison groups, sites, endpoints, reported paths, symptoms, onset/latest occurrence, time window, current impact, trend, and time sensitivity. Ask what changed recently and state which change sources were checked. Use `unknown` when unchecked; do not assign severity without an approved definition. [Sources: `SRC-002` §§4.1, 5; `SRC-003` items 5–9; `SRC-007` “Minimum case context” and “Triage sequence.”]

## Preserve intermittent patterns

Record individual failure times with timezone, approximate onset, frequency, episode duration, whether it continues, observation window/sample count, affected and unaffected cohorts, destination, test method, and exact error/behavior when known. Keep each gateway/device/path report separate with its source, time, scope, and identification method. Compare whether reports refer to the same user/endpoint, device/path, time, and scope; label an apparent difference, unresolved conflict, or evidence-resolved conflict. Do not select the most plausible report. [Sources: `SRC-002` §4.1; `SRC-003` item 6; `SRC-007` “Capture intermittent patterns” and “Conflict resolution pattern.”]

## Bound monitoring claims

Before weighing a healthy/green result, identify the target, measurement, probe origin and path, coverage, collection interval, timestamp, and freshness. A point-in-time green result supports only the measured scope and time; it does not establish service health for all users or the full incident window. [Sources: `SRC-002` §4.1; `SRC-003` item 7; `SRC-007` “Capture intermittent patterns.”]

## Safe checks and action boundary

For every recommended check, state purpose; read-only observation versus state-changing action; scope; prerequisites and human owner; expected observations and what each means; risk/blast radius; required authorization; stop condition; and rollback/verification for state changes. Identify which read-only checks are independent and which depend on each other. No production action is executed by the brain. [Sources: `SRC-002` §§5–6; `SRC-003` “Response contract”; `SRC-004` “Expected incident assessment.”]

## Quality warning from the synthetic test

Dry Test 001 found that the tested answer named useful checks but did not give the required per-check interpretation, risk, authorization, or stop conditions; it also showed a mismatch between the charter and OS about competing explanations. The v0.2 bundle revised the written contract, but one synthetic test does not establish reliable performance. See [evaluation record](../../40-evaluations/field-operator-dry-test-001.md). [Source: `SRC-006` “Findings and required changes,” “Structural control results,” and “Interpretation.”]

## Related pages

- [Field Operator mission and boundary](mission-and-boundary.md)
- [Evidence model](../system/evidence-model.md)
- [Learning and evaluation](learning-and-evaluation.md)

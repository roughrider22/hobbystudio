---
page_id: field-operator-learning-evaluation
status: draft_synthesis
created: 2026-10-05
updated: 2026-10-05
source_ids: [SRC-001, SRC-002, SRC-003, SRC-004, SRC-008]
tags: [field-operator, learning, evaluation]
---

# Learning and Evaluation

## Knowledge lifecycle

Keep case context, candidate learning, accepted guidance, evaluation evidence, and instructions separate. A correction or verified outcome may produce a candidate record with evidence, scope, inference, applicability, limits, counterchecks, reviewer decision, and evaluation. Preserve the case finding and challenges. The same brain cannot approve its own candidate. [Sources: `SRC-001` “Learning lifecycle” and “Candidate learning record”; `SRC-002` §§7, 9; `SRC-003` “Wiki maintenance”; `SRC-008` “Propose a learning.”]

## Candidate to accepted guidance

1. Notice a correction, verified outcome, recurring context gap, surprise, or disagreement.
2. Record the candidate separately from the case; attach source references and scope.
3. Review evidence quality, privacy, freshness, counterexamples, and applicability.
4. Test proposed wiki/charter/workflow changes against representative and edge cases.
5. Have a designated human reviewer accept, reject, or defer it; preserve the rationale and prior version.
6. Revisit it when evidence contradicts it, becomes stale, or evaluation no longer holds.

The reviewer role and acceptance process are currently unassigned. Thus no candidate can be marked accepted under this bootstrap contract. See [Open decisions](../system/open-decisions.md) and the [candidate template](../../50-templates/learning-candidate.md).

## Measures and limits

Candidate quality measures named by the source set are accuracy, useful direction, timeliness, context quality, risk handling, and improvement over time. Define reviewers, scales, and targets before numeric scoring. Structural control checks may be recorded as pass/fail/not applicable; qualitative reviewer ratings must remain distinct from them. A synthetic test can reveal instruction gaps, but it cannot validate network-specific procedures. [Sources: `SRC-001` “Evaluation and improvement”; `SRC-002` §6.1 and §9; `SRC-004` “Pilot quality measures”; `SRC-008` “Audit the wiki.”]

## Current state

No operational learning candidates or accepted guidance were created from this starter set. The dry test is retained under evaluations as `evaluation_only`; its findings support revisions to the written design, not field troubleshooting rules. The evaluation is one qualitative synthetic desk test with no assigned reviewer, scoring rubric, or numeric rating. See [Dry Test 001](../../40-evaluations/field-operator-dry-test-001.md).

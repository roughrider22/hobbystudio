---
page_id: evidence-model
status: draft_synthesis
created: 2026-10-05
updated: 2026-10-05
source_ids: [SRC-001, SRC-002, SRC-003, SRC-008, SRC-010]
tags: [evidence, governance, knowledge-status]
---

# Evidence Model and Knowledge Status

## Summary

The system separates original evidence, source-linked wiki synthesis, learning candidates, accepted guidance, evaluation records, and operating instructions. Each layer has a different authority. The written contract is a draft; it does not establish live network truth or independent model learning. [Sources: `SRC-001` “Shared evidence rules” and “Dynamic schema”; `SRC-002` §§1, 7–9; `SRC-003` “Evidence boundaries”; `SRC-008` “Separate the layers”; `SRC-010` “Architecture.”]

## Working distinctions

| Layer | Use | Boundary |
|---|---|---|
| Raw source | Preserve user-supplied or permitted originals | Source content is evidence of what is written/recorded, not automatic proof of the real-world claim |
| Evidence record | Track source, time, scope, validation, freshness, authority, and limits | Registering a source does not grant access or establish authority |
| Wiki synthesis | Make reviewed source material findable and connected | Not live state; consequential claims keep source references |
| Learning candidate | Propose scoped reusable lesson | Not accepted, policy, or operational truth |
| Accepted guidance | Reuse human-reviewed guidance within stated scope | Not universal truth or current configuration |
| Instructions | Govern agent behavior and workflows | Not a source of network facts |
| Evaluation | Measure behavior against test cases | Synthetic results do not validate network procedures |

## Claim-level evidence states

Use `reported` for a user or source report; `observed` for directly seen evidence with method/time/scope; `validated` only when the stated check supports the claim; `inferred` for a conclusion from evidence; `assumed` for an unverified premise; `stale` when freshness is inadequate; `conflicting` when incompatible claims remain; and `unknown` when not established. Record the source and scope alongside the state. [Sources: `SRC-001` “Shared evidence rules”; `SRC-002` §§4, 7; `SRC-003` “Read and use the wiki.”]

## Current instance

All Field Operator pages in this bootstrap are draft design synthesis except [Dry Test 001](../../40-evaluations/field-operator-dry-test-001.md), which is `evaluation_only`. There is no accepted network troubleshooting guidance in this vault. The starter's main governance decisions—reviewer, source authority/freshness, data policy, access, persistence, and evaluation thresholds—remain open. See [Open decisions](open-decisions.md).

## Related pages

- [Field Operator mission and boundary](../field-operator/mission-and-boundary.md)
- [Learning and evaluation](../field-operator/learning-and-evaluation.md)
- [Source registry](../../10-sources/SOURCE_REGISTRY.md)

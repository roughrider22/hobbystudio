# Archive

Retain retired or superseded wiki pages here only when their prior wording or decision matters for traceability. Add a banner to the archived page, link it to the current page, explain why it was retired, and append a log entry. Raw originals stay under `10-sources/raw/` and are never moved here or rewritten.

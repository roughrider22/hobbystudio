# Field Operator Second Brain

**Version:** 0.1 bootstrap  
**Status:** Working draft; not an approved operational procedure or deployed agent.

This vault combines a source-preserving archive, a linked draft wiki, operating rules, and a dated change log. It is initialized from the supplied Field Operator v0.2 bundle and `02-LLM_WIKI.md`.

## Start here

1. The root [AGENTS.md](AGENTS.md) is the agent boot file; it directs the agent to read [MAIN.md](MAIN.md) before ingesting or answering.
2. Use [INDEX_MAIN.md](INDEX_MAIN.md) to find content and open decisions.
3. Use [10-sources/SOURCE_REGISTRY.md](10-sources/SOURCE_REGISTRY.md) to trace claims to the exact original file.
4. Review [LOG.md](LOG.md) for what changed and when.

## Open as an Obsidian vault

Extract this folder and open `Field_Operator_Second_Brain_v0.1` as a vault in Obsidian. The files use ordinary Markdown links and need no plugin. Git version history is optional; add it only after local data-handling requirements are clear.

New sources go in `00-inbox/` for intake. Once identified and accepted for handling, preserve an unchanged copy under `10-sources/raw/`, register it, then ask the agent to ingest that source. Do not put credentials or unnecessary personal or production-sensitive data in this vault.

## Current limits

This is a structured, durable file set. Its existence does not prove that a future assistant session can access it, that a model has been retrained, or that live network sources are connected. At bootstrap, no live network data, source authority, reviewer assignment, retention policy, or production access was supplied.

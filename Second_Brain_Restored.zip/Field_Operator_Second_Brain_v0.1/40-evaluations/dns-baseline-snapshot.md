---
page_id: dns-baseline-snapshot
status: evaluation_only
created: 2026-10-07
updated: 2026-10-07
source_ids: [SRC-011]
tags: [dns, transport, historical-baseline]
---
# DNS transport: first-source baseline

Historical snapshot: RFC 5966 is obsolete. This records its position for comparison.

- General-purpose DNS implementations require UDP and TCP support. [SRC-011, section 4](../10-sources/raw/rfc5966.txt)
- UDP first is recommended, with TCP permitted for operational reasons. [SRC-011, section 4](../10-sources/raw/rfc5966.txt)
- A successful UDP query does not establish TCP reachability. This is an inference about test coverage.
- No local timeout cause is established by a standard.
---
page_id: field-operator-dry-test-001
status: evaluation_only
created: 2026-10-05
updated: 2026-10-05
source_ids: [SRC-006, SRC-002, SRC-003]
tags: [evaluation, synthetic, field-operator]
---

# Field Operator Dry Test 001

**Status:** Synthetic qualitative desk test. Not a real incident, not accepted operational knowledge, and not validation of a network procedure.

## Scenario boundary

Several Office A users report intermittent timeouts to an internal application. User count and path are unknown; one application-monitoring result was green; recent changes were not checked; reports name different gateways. The source explicitly marks this scenario synthetic. No live network was accessed. [Source: `SRC-006`, “Scenario” and “Use boundary.”]

## What the test observed

The response kept symptoms/unknowns/inferences apart, did not select a gateway or assert a root cause, limited the point-in-time monitor result, noted unchecked changes, and stayed advisory. It did not fully satisfy its own rules: source/time provenance was partial; alternatives lacked specific disconfirming checks; per-check expected-result interpretations, risk, authorization, and stop conditions were missing; the charter/OS output contracts were misaligned. [Source: `SRC-006`, “Observed response strengths” and “Structural control results.”]

## Design changes recorded by the original test

The supplied v0.2 OS adds explicit impact and intermittent-pattern questions, a source/time/scope/method comparison for conflicting paths, monitoring scope questions, a per-check response format, aligned competing explanations, dependency-aware parallelism, and structural control checks. These are draft contract changes prompted by one synthetic case; they do not establish that the system now complies reliably. [Sources: `SRC-006`, “Findings and required changes”; `SRC-002` §12.]

## Interpretation

Use this case to test instruction-following and reveal design gaps. Do not reuse Office A, the application timeouts, the gateways, or the green monitor as network facts. Do not create an operational learning record from the fictional scenario. More evaluation cases, an assigned reviewer, a scoring rubric, and appropriate approved historical or live data would be needed for stronger readiness claims. [Sources: `SRC-006`, “Interpretation” and “Status”; `SRC-002` §6.1 and §9.]

## Related pages

- [Incident intake and triage](../20-wiki/field-operator/incident-intake-and-triage.md)
- [Learning and evaluation](../20-wiki/field-operator/learning-and-evaluation.md)
- [Source registry](../10-sources/SOURCE_REGISTRY.md)

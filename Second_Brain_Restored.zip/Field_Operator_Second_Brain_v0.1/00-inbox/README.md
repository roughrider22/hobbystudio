# Inbox — New Sources Awaiting Intake

Place new candidate materials here without renaming or editing them. An inbox file has not yet been registered, checked for permitted handling, or incorporated into the wiki.

For each new source, ask the wiki agent to ingest the exact filename and confirm:

1. the file opened correctly and what the material actually contains;
2. source identity, scope/date, owner/authority, sensitivity, and use limits—or `unknown` where absent;
3. whether it is evidence, opinion, policy, a design draft, an example, or synthetic material;
4. the source ID and immutable archive path;
5. which pages should change and which claims remain uncertain;
6. the updated index, appended log entry, and link/evidence validation.

After review, preserve an unchanged copy in `10-sources/raw/` and update `10-sources/SOURCE_REGISTRY.md`. Do not delete the inbox copy unless the user approves the archive/retention action and the raw copy is verified. Do not add secrets or unnecessary sensitive details.

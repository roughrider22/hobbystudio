# First Ingest — Completed Bootstrap and Next Source

## Status

The supplied starter bundle and `02-LLM_WIKI.md` have already been ingested into the vault. This guide documents that work and gives the repeatable steps for the next, single-source ingest. Do not re-ingest the starter set unless the user explicitly asks for a re-review or identifies a changed source version.

## Part A — What the initial ingest did

1. **Confirm inputs.** Verified a ZIP with nine Markdown files and a separate `02-LLM_WIKI.md` (ten source documents total, plus the ZIP wrapper).
2. **Classify claims.** Distinguished working drafts, design references, pilot wiki material, and the explicitly synthetic dry test.
3. **Preserve originals.** Kept the uploaded ZIP and separate Markdown unchanged under `10-sources/raw/`; extracted source originals were retained for direct reading.
4. **Register sources.** Assigned `SRC-001`–`SRC-010` and `PKG-001`; recorded SHA-256 hashes and limitations in `10-sources/SOURCE_REGISTRY.md`.
5. **Synthesize drafts.** Built linked pages for the evidence model, open decisions, LLM Wiki method, Field Operator scope, incident intake/triage, and learning/evaluation.
6. **Isolate evaluation.** Kept the Office A timeout dry test under `40-evaluations/` with `evaluation_only` status. It did not create a real incident or accepted lesson.
7. **Navigate and log.** Updated `INDEX_MAIN.md` and appended the setup/ingest/audit history to `LOG.md`.
8. **Validate.** Checked local Markdown links, source presence, status boundaries, and byte equality of the preserved ZIP and standalone wiki input. These checks validate file integrity and structure, not operational correctness.

The interactive six-step version is `first-ingest-walkthrough.html`. Open it in a browser, then use its **Previous/Next** buttons or step selector to move through the intake.

## Part B — Ingest the next source, one at a time

### Step 1: Confirm the boundary

Ask the user to identify the source, its owner, intended use, affected scope, relevant date/time range, and permitted handling. Confirm that the destination account and storage location are approved for it. Do not put credentials or unnecessary personal/production-sensitive data into the vault.

**Pause if:** ownership, permission, classification, or retention is unknown and the material may be sensitive. Keep the source out of the vault until the user resolves the handling boundary.

### Step 2: Stage the original

Place the received file in `00-inbox/`. Record its exact filename, format, size, received date, and whether it opens. Keep the original bytes unchanged. For a package, inspect its inventory before claiming the contents were reviewed.

### Step 3: Decide whether to preserve and register

If accepted for handling, copy the original into `10-sources/raw/`, calculate SHA-256 when available, assign the next stable `SRC-###`, and add a registry entry with origin, scope, dates, authority, validation state, limitations, and handling restrictions. Use `unknown` where the source does not establish a fact.

### Step 4: Read and extract claims

Separate direct statements, measurements, recommendations, examples, and the source author's conclusions. Capture exact section/page/time references. Mark statements as reported, observed, validated, inferred, assumed, stale, conflicting, or unknown as supported.

### Step 5: Compare with the current wiki

Read `INDEX_MAIN.md`, then only the relevant pages and sources. Note agreement, conflict, scope mismatch, possible supersession, and sources that are referenced but absent. Do not resolve conflicts by choosing the newest-looking or most confident claim without an authority rule.

### Step 6: Draft the smallest useful update

Create or revise only affected `20-wiki/` pages. Keep them `draft_synthesis` unless an assigned reviewer explicitly approves scoped guidance. Preserve a clear link from each material claim to its source ID and precise source location. Keep case-specific content separate from reusable learning.

### Step 7: Review consequential interpretation

Show the user material interpretations, conflicts, and any proposed operational implication. Ask only questions whose answers change the scope, safety, or conclusion. Do not turn the source into production instructions or imply change authorization.

### Step 8: Update index and log

Add or revise the content link/status in `INDEX_MAIN.md`. Append a dated entry to `LOG.md` with the source ID, title, affected pages, ingest status, decisions pending, and validation performed. Do not rewrite earlier history; append a correction if needed.

### Step 9: Validate and report

Check Markdown links, source IDs and locations, file hashes if used, page statuses, privacy, unsupported claims, and whether the synthesis preserves source limits and disagreements. Report what was read, what changed, what remains unknown, and whether user review is pending.

## Completion labels

- `ingest_pending_review` — parsing and draft work are done, but required user/reviewer decisions remain.
- `draft_synthesis` — source-linked summary exists but is not approved guidance.
- `accepted_guidance` — only after the assigned human review process approves it for a stated scope.

Never report acceptance, live validation, or network readiness merely because the file was parsed or links passed.

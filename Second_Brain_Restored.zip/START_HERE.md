# Start Here — Cross-Account Handover

This package carries the Field Operator Second Brain project to a different ChatGPT account. It contains the complete current vault, its preserved inputs, the project handover, a first-ingest guide, and a reusable prompt for the new account.

## Transfer sequence

1. **Keep the ZIP intact.** Move it using a method approved for the data and both accounts. The source set is mostly design material, but its handling classification has not been confirmed.
2. **Extract to a staging location first.** Do not overwrite the existing OneDrive vault. Compare the extracted folder with the destination and make a backup before merging or replacing anything.
3. **Start a new conversation in the destination account.** Upload this whole ZIP. If you intend to work directly in the Windows folder, use a supported local workspace and verify that the new account actually has access. A file upload does not transfer local OneDrive permissions, account memory, conversation history, connected apps, or workspace settings.
4. **Copy `NEW_ACCOUNT_BOOTSTRAP_PROMPT.md` into the new conversation.** It tells the next agent what to inspect and what it must verify before continuing.
5. **Check the handoff.** Ask the new agent to list the files it can read, identify three key facts from the vault, state its actual live-network and file-access limits, and report any missing files or broken links. Do not proceed based on an unverified claim that the archive was fully read.
6. **Resume from the open decisions.** The starter set is already ingested. Do not repeat it as a new ingest. First resolve the relevant ownership, data-handling, persistence, and review questions; then select one permitted next source for ingestion.

## Quick links inside this package

- [Project handover](HANDOVER.md)
- [Step-by-step ingest guide](FIRST_INGEST_GUIDE.md)
- [Prompt for the new account](NEW_ACCOUNT_BOOTSTRAP_PROMPT.md)
- [Package contents](PACKAGE_CONTENTS.md)
- [Interactive first-ingest walkthrough](first-ingest-walkthrough.html)
- Vault root: `Field_Operator_Second_Brain_v0.1/`

## Safe continuation rule

Treat `MAIN.md` as the current working contract, not as organizational policy. Draft wiki pages remain drafts. The Office A timeout case is synthetic and evaluation-only. No live network access, authorized source connection, operational approval, or accepted learning is established by this package.
